    const express = require('express');
const cors = require('cors');
//definir a porta
const porta = 3001;
const app = express();
//habilitar o cors e utilizar json
app.use(cors());
app.use(express.json());
//testar
app.listen(porta, () => console.log(`rodando na porta ` + porta));
 
 
const connection = require('./db_config');
const upload = require('./multer')
 
app.post('/usuario/cadastrar', (request, response) => {
    let params = Array(
        // request.body.usuario,
        // request.body.id,
        request.body.cpf,
        request.body.nome,
        request.body.email,
        request.body.senha
    );
 console.log(params)
    // let query = "INSERT INTO usuarios(usuario, id, cpf, nome, email, senha) values(?,?,?,?,?,?);";
    let query = "INSERT INTO usuarios(cpf, nome, email, senha) values(?,?,?,?);";
   
    connection.query(query, params, (err, results) => {
        if(results) {
            response
            .status(201)
            .json({
                success: true,
                message: "Sucesso",
                data: results
            })
 
        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "Sem sucesso",
                data: err
            })
        }
    })
});
 

app.post('/produto/cadastrar', upload.single('file'), (request, response) => {
    let params = Array(
        request.body.nome_produto,
        request.body.price,
        request.body.description,
        request.file.filename
    )

    let query = "INSERT INTO produtos(nome_produto, preco_produto, descricao_produto, imagem) VALUES(?,?,?,?)";

    connection.query(query,params, (err, results) => {
        if(results) {
            response
            .status(201)
            .json({
                success: true,
                message: "Sucesso",
                data: results
        })
        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "Sem sucesso",
                data: err
            })
        }

    })
})
 



app.post('/usuario/login', (request, response) => {
    let params = Array(
        request.body.email,
            // request.body.senha
    );
    let query = "SELECT usuario,id_usuario,cpf,nome,email,senha FROM usuarios WHERE email = ?";
 
    connection.query(query, params, (err, results) => {
        if(results.length > 0) {
            let senhaDigitada = request.body.password
            let senhaBanco = results[0].senha

            if (senhaBanco === senhaDigitada) {

                response
                    .status(201)
                    .json({
                        success: true,
                        message: "Sucesso",
                        data: results[0]
                })
                
            } else {
                response
                    .status(400)
                    .json({
                    success: false,
                    message: "Verifique sua senha!",
                    data: err
                })
            }

        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "E-mail não cadastrado",
                data: err
            })
        }
       
    })
})

app.use('/uploads', express.static(__dirname + '\\public'))

app.get('/produtos/listar', (request, response) => {
    let query = "SELECT * FROM produtos";

    connection.query(query, (err, results) => {
        if(results) {
            response
                .status(201)
                .json({
                    success: true,
                    message: "Sucesso",
                    data: results[0]
                })
        } else {
            response
                .status(400)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                })
        }
    })
})

app.put('/produto/:id', upload.single('imagemProduto'), (request, response) => {
    let params = Array(
        request.body.id_produto,
        request.body.nome_produto,
        request.body.preco_produto,
        request.file.imagem,
        request.body.descricao_produto,
        request.params.id_produto
    )
    console.log(params)
    let query = `UPDATE produtos SET nome_produto = ?, preco_produto = ?, imagem = ?,, descricao_produto = ? WHERE id_produto = ?`
 
    connection.query(query, params, (err, results) =>{
        if(results) {
            response
            .status(200)
            .json({
                success: true,
                message: "suceesso!",
                data: results
            })
 
        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "sem sucesso",
                data: err
            })
        }
    })
})