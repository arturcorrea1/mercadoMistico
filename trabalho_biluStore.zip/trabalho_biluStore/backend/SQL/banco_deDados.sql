create database Bilu_StoreOFC; 
use Bilu_StoreOFC;

create table usuarios(
	usuario enum("Cliente", "Administrador") default("Cliente"),
    id_usuario int not null primary key auto_increment,
    cpf varchar(45) unique,
    nome varchar(45),
    email varchar(45) unique,
    senha varchar(45)
);

create table produtos( 	
	id_produto int primary key not null auto_increment,
	nome_produto varchar(40),
	preco_produto float,
	quantidade_produto int,
	descricao_produto text not null,
	imagem text not null
	-- create_data timestamp default current_timestamp
);

create table carrinho(
	id_carrinho int primary key auto_increment,
	valor_total float,
	qtd_produto int,
	id_usuario int,
	id_produto int,
	foreign key (id_produto) references produtos(ID_produto),
	foreign key (id_usuario) references usuarios(id_usuario)
);

ALTER TABLE produtos ADD COLUMN imagem text not null;

ALTER TABLE produtos MODIFY descricao_produto text not null;

-- insert into usuarios(usuario,cpf,nome,email,senha)
-- VALUES("Cliente", "07608686", "Manoel Gomez", "canetaazul@gmail.com", "1234");
-- SELECT usuario,id_usuario,nome,email,senha FROM usuarios WHERE email = "canetaazul@gmail.com";

select * from usuarios;
select * from produtos;
select * from carrinho