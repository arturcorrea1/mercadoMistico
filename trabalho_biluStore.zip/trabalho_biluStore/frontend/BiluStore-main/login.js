async function logar(event) {
    event.preventDefault();

    // const email = document.querySelector('#emailLogin').value;
    // const password = document.querySelector('#senha').value;

    const email = document.getElementById('emailLogin').value;
    const password = document.getElementById('senha').value;

    const data = {email,password};

    const response = await fetch('http://localhost:3001/usuario/login', {
        method: "POST",
        headers: {
            "Content-Type":"application/json"
        },
        body: JSON.stringify(data)      
    })

    let results = await response.json();

    if(results.success) {



        let userData = results.data;

        localStorage.setItem('informacoes', JSON.stringify(userData))




        window.location.href = "index.html"

        alert(results.message)
    } else {

        alert(results.message)
    }
}



// FUNÇÃO DE LOGOUT

function sair() {
    localStorage.removeItem('informacoes')
    window.location.href = "index.html"
}


// ------------------------------------------------------------------------------

// LOAD !!! PERFIL USUÁRIO e ADICIONAR PRODUTO (HABILITAR E DESABILITAR)

    window.addEventListener("load", () => {
        if(localStorage.getItem("informacoes")) {   
            let html = document.getElementById('informacoes')
            let dados = JSON.parse(localStorage.getItem('informacoes'))

            if(dados.usuario === 'Administrador'){
                document.getElementById('cadastrar_produto').style.display = 'block'
            } else {
                document.getElementById('cadastrar_produto').style.display = 'none'
            }

            html.innerHTML = `<div style="display: flex; flex-direction: column; align-items: end">
                nome: ${dados.nome} email: ${dados.email} Perfil: ${dados.usuario}
             </div>`

            html.style.display = 'block'

        }
    })


// --------------------------------------------------------------------------------

