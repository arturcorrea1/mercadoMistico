let perfilData = localStorage.getItem('infoUsuario')
 
    document.addEventListener("DOMContentLoaded", () => {
        let perfil = JSON.parse(perfilData).perfil
        listarProdutos()
 
        if(perfil === 'Administrador'){
            alert('Você é admin')
        }else{
            alert('Você não é admin')
            window.location.href='./login/login.html'
        }
    });
 

async function listarProdutos() {
    const response = await fetch('http://localhost:3001/produtos/listar', {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    })

    const results = await response.json()

    if(results.success) {
        let productData = results.data
        const images = 'http://localhost:3001/uploads/'
        let html = document.getElementById('produtos')

        productData.forEach(product => {
            console.log(product)
            let card = `
                <div id="produtos">
                <div>
                    <h1 id="tituloProdutos">${product.nome_produto}</h1>
                    <div class="imagens">
                        <img src="${images + product.imagem}" alt="" height="150vh" width="250vw">
                    </div>
                    <div style="display: flex; justify-content: center; align-items: center;">
                        <h1 id="preçoProdutos">${product.price}</h1>
                        <div class="botaoAdd_carrinho" onclick="addCarrinho ${product}" style="margin-left: 5vh;">
                            Adicionar ao carrinho
                        </div>
                    </div>
                    <p style="color: white;">
                    ${product.description}
                    </p>
                </div>
            </div>
            `
            html.innerHTML += card
        });

    } else {
        alert(results.message)
    }
}

// Linkar com o load