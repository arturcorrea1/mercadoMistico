async function cadastrarProduto(event) {
    event.preventDefault();

    const nome_produto = document.getElementById('nome_produto').value
    const price = Number(document.getElementById('price').value)
    const description = document.getElementById('description').value
    const file = document.getElementById('file').files[0]

    let formData = new FormData();

    console.log(nome_produto, price, description, file);

    formData.append('nome_produto', nome_produto)
    formData.append('price', price)
    formData.append('description', description)
    formData.append('file', file)

    const response = await fetch('http://localhost:3001/produto/cadastrar', {
        method: "POST",
        body: formData
    })

    const results = await response.json()
    if(results.success) {
        alert(results.message)
    } else {
        alert(results.message)
    }

    
}